import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Simulated annealing algorithm implementation for the Bin Packing problem.
 */
public class SimulatedAnnealing {

    private static final double INITIAL_TEMP = 10000;
    private static final double COOLING_RATE = 0.003;

    /**
     * Bin class represents a single bin with a capacity and items it contains.
     */
    static class Bin {
        int capacity;
        List<Integer> items;
        long computationTime;

        public Bin(int capacity) {
            this.capacity = capacity;
            this.items = new ArrayList<>();
            this.computationTime = 0;
        }

        boolean addItem(int item) {
            long startTime = System.nanoTime();
            if (currentLoad() + item <= capacity) {
                items.add(item);
                computationTime += System.nanoTime() - startTime;
                return true;
            }
            computationTime += System.nanoTime() - startTime;
            return false;
        }

        int currentLoad() {
            return items.stream().mapToInt(Integer::intValue).sum();
        }
    }

    /**
     * Executes the simulated annealing process to minimize the number of bins.
     *
     * @param items       the list of item weights to pack
     * @param binCapacity the maximum capacity of each bin
     * @return a list of bins representing the solution
     */
    public List<Bin> simulatedAnnealing(List<Integer> items, int binCapacity) {
        double temp = INITIAL_TEMP;
        List<Bin> currentSolution = initialSolution(items, binCapacity);
        double currentEnergy = evaluateSolution(currentSolution);

        List<Bin> bestSolution = new ArrayList<>(currentSolution);
        double bestEnergy = currentEnergy;

        while (temp > 1) {
            List<Bin> newSolution = generateNeighbor(currentSolution, binCapacity, items);
            double newEnergy = evaluateSolution(newSolution);
            if (shouldAccept(currentEnergy, newEnergy, temp)) {
                currentSolution = newSolution;
                currentEnergy = newEnergy;
            }

            if (currentEnergy < bestEnergy) {
                bestSolution = new ArrayList<>(currentSolution);
                bestEnergy = currentEnergy;
            }

            temp *= 1 - COOLING_RATE;
        }

        return bestSolution;
    }

    /**
     * Evaluates the given solution based on the number of bins used.
     *
     * @param solution the list of bins representing a solution
     * @return the energy or cost associated with the solution
     */
    private double evaluateSolution(List<Bin> solution) {
        return solution.size();
    }

    /**
     * Determines whether a new solution should be accepted over the current one.
     *
     * @param currentEnergy the energy of the current solution
     * @param newEnergy     the energy of the new solution
     * @param temperature   the current temperature of the annealing process
     * @return true if the new solution is accepted, false otherwise
     */
    private  boolean shouldAccept(double currentEnergy, double newEnergy, double temperature) {
        if (newEnergy < currentEnergy) {
            return true;
        }
        return Math.exp((currentEnergy - newEnergy) / temperature) > Math.random();
    }

    /**
     * Generates a neighbor solution by making a small change to the current solution.
     *
     * @param currentSolution the current solution from which to generate a neighbor
     * @param binCapacity     the maximum capacity of each bin
     * @param items           the list of item weights available for packing
     * @return a new solution representing a neighbor
     */
    private  List<Bin> generateNeighbor(List<Bin> currentSolution, int binCapacity, List<Integer> items) {
        List<Bin> newSolution = new ArrayList<>(currentSolution);
        Random random = new Random();
        int binIndex1 = random.nextInt(newSolution.size());
        int binIndex2 = random.nextInt(newSolution.size());

        if (!newSolution.get(binIndex1).items.isEmpty() && binIndex1 != binIndex2) {
            int itemIndex = random.nextInt(newSolution.get(binIndex1).items.size());
            int item = newSolution.get(binIndex1).items.remove(itemIndex);

            if (!newSolution.get(binIndex2).addItem(item)) {
                newSolution.get(binIndex1).addItem(item);
            }
        }

        newSolution.removeIf(b -> b.items.isEmpty());
        return newSolution;
    }

    /**
     * Generates an initial solution using a heuristic before the annealing process starts.
     *
     * @param items       the list of item weights to pack
     * @param binCapacity the maximum capacity of each bin
     * @return a list of bins representing the initial solution
     */
    private List<Bin> initialSolution(List<Integer> items, int binCapacity) {
        List<Bin> bins = new ArrayList<>();
        items.forEach(item -> {
            Optional<Bin> bin = bins.stream().filter(b -> b.addItem(item)).findFirst();
            if (!bin.isPresent()) {
                Bin newBin = new Bin(binCapacity);
                newBin.addItem(item);
                bins.add(newBin);
            }
        });
        return bins;
    }

    public static void main(String[] args) {
        SimulatedAnnealing simulatedAnnealingObject = new SimulatedAnnealing();

        String filePath = "BPP.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("'TEST")) {
                    String testName = line.trim();
                    int m = Integer.parseInt(br.readLine().trim());
                    int capacity = Integer.parseInt(br.readLine().trim());

                    List<Integer> items = simulatedAnnealingObject.parseItems(br, m);

                    List<Bin> solution = simulatedAnnealingObject.simulatedAnnealing(items, capacity);

                    simulatedAnnealingObject.printSolution(testName, items, capacity, solution);
                }
            }
        } catch (IOException e) {
            System.out.println("File not found or could not be read.");
            e.printStackTrace();
        }
    }

    /**
     * Parses the item weights and their quantities from the input file.
     *
     * @param br         the BufferedReader to read from
     * @param itemCount  the number of different items
     * @return a list of item weights, considering the quantity of each
     * @throws IOException if an I/O error occurs
     */
    private  List<Integer> parseItems(BufferedReader br, int itemCount) throws IOException {
        List<Integer> items = new ArrayList<>();
        for (int i = 0; i < itemCount; i++) {
            String[] itemInfo = br.readLine().trim().split("\\s+");
            int weight = Integer.parseInt(itemInfo[0]);
            int count = Integer.parseInt(itemInfo[1]);
            items.addAll(Collections.nCopies(count, weight));
        }
        return items;
    }

    /**
     * Prints the solution to the Bin Packing problem in a formatted manner.
     *
     * @param testName   the name of the test case
     * @param items      the list of item weights
     * @param capacity   the maximum capacity of each bin
     * @param solution   the list of bins representing the solution
     */
    private void printSolution(String testName, List<Integer> items, int capacity, List<Bin> solution) {
        System.out.println('"' + testName + '"');
        System.out.print("Available Weights: ");
        System.out.println(items.stream().distinct().map(String::valueOf).collect(Collectors.joining(", ", "[", "]")));
        System.out.println(String.format("Maximum Bin Size: %d", capacity));

        for (int i = 0; i < solution.size(); i++) {
            System.out.println(String.format("Bin %d:", i + 1));
            System.out.println(solution.get(i).items.stream().map(String::valueOf).collect(Collectors.joining(", ", "[", "]")));
            System.out.println(String.format("Computation Time: %d N/S", solution.get(i).computationTime)); // print computation time
        }

        System.out.println(String.format("\nNumber of bins used: %d", solution.size()));
        System.out.println("\n-----------------------------------\n");
    }
}
